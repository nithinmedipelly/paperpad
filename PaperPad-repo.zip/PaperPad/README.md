# PaperPad

> Repository name: **SCAMslayer** &nbsp;·&nbsp; App name: **PaperPad**

A voice-first notebook for people who'd rather talk than type. Built especially for older users — anyone used to writing things down on paper but tired of fumbling with tiny keyboards.

## What it does

You tap one big button, speak naturally, and your words become tidy bullet points on the screen. Need a table? Say "make a table," speak each cell, and PaperPad fills it in column by column. When you're done, save it as a **PDF**, **Word document**, or **plain text file**, or share it directly via WhatsApp, Email, SMS, or your phone's native share menu.

## What's new in v3.2 (more languages + language-switch bug fix)

### Bug fix: microphone wouldn't restart on some languages

When you picked a language your browser didn't have a voice model for (some Indian languages, Hebrew, Thai, etc.), recognition silently looped on `language-not-supported` errors and the microphone never came back on until you switched to English. Fixed:

- The error code is now handled explicitly with a clear message: *"Sorry — your browser cannot listen in [Language]. Try a different language (English usually works), or just type your notes here."*
- Language switching uses a clean stop-and-restart sequence so the new language always starts fresh
- A consecutive-failure counter prevents the recognition from spinning forever after 3 failed attempts

### Numbers in 28+ languages

Number-word → digit conversion now works in:

- **English** (US/UK/India with lakh, crore)
- **Spanish, French, German, Italian, Portuguese, Dutch, Polish, Russian, Turkish**
- **Hindi** (Devanagari + romanised), **Punjabi, Gujarati, Kannada, Malayalam, Bengali, Marathi, Tamil, Telugu, Urdu**
- **Arabic, Hebrew**
- **Japanese, Chinese (Simplified/Traditional), Korean** — with proper "myriadic" parsing so 五千万 → 50,000,000 and 一亿 → 100,000,000
- **Thai, Vietnamese, Indonesian**

Examples:

| Language | You say | App writes |
|----------|---------|------------|
| English | *"twenty five point nine nine"* | **25.99** |
| English-IN | *"one crore twenty five lakh"* | **12500000** |
| Hindi | *"दो लाख पचास हज़ार"* | **250000** |
| Spanish | *"doscientos cincuenta"* | **250** |
| French | *"le prix est vingt virgule cinq"* | **le prix est 20.5** |
| Vietnamese | *"hai trăm năm mươi nghìn"* | **250000** |
| Indonesian | *"dua ratus lima puluh ribu"* | **250000** |
| Japanese | *"五千万"* | **50000000** |
| Chinese | *"二百五十"* | **250** |
| Korean | *"이백오십"* | **250** |
| Punjabi | *"ਪੰਜਾਹ"* | **50** |
| Malayalam | *"അമ്പത്"* | **50** |

For languages without a number dictionary, modern speech recognition usually returns digits natively anyway, so they pass through unchanged.

## What's new

- **30+ languages** — pick from English (US/UK/India), Hindi, Telugu, Tamil, Bengali, Marathi, Gujarati, Punjabi, Kannada, Malayalam, Urdu, Spanish, French, German, Italian, Portuguese, Russian, Arabic, Chinese, Japanese, Korean, and more. Your choice is remembered.
- **Header-driven tables** — speak/type the column names first ("Name, Age, City") and PaperPad creates exactly that many columns. Each cell is filled by voice, with an active cell highlighted so you always know where you are.
- **"Next Cell" / "Next Row" buttons** plus the matching voice commands. The active cell auto-advances when full, or you can tap to jump to any cell.
- **Share with Someone** — opens a menu with: phone's native share sheet (WhatsApp, Telegram, Mail, etc.), Email (mailto), WhatsApp, SMS, and Copy to Clipboard. No sign-in needed — uses your phone's built-in apps.

## Voice commands (English)

| Say this                                                                | What happens                                  |
|-------------------------------------------------------------------------|-----------------------------------------------|
| "next point" / "new bullet"                                             | Starts a new bullet                           |
| "erase that" / "erase the last bullet" / "scratch that" / "remove that" | Removes the last bullet                       |
| "make a table" / "create a table"                                       | Opens the table builder                       |
| (in table mode) "next cell" / "next column"                             | Moves to the next cell in the row             |
| (in table mode) "next row" / "new row"                                  | Starts a new row                              |
| (in table mode) "finish table" / "done table"                           | Saves the table and goes back to your notes   |
| (in table mode) "set headers" / "done with headers"                     | Confirms headers and switches to data entry   |
| (in table mode) "cancel table"                                          | Discards the table                            |

Voice commands are recognised in English. In other languages, dictate your content normally and use the buttons (Next Point, Next Cell, Next Row, Finish Table) for navigation.

## Numbers come out as digits

In English, *"twenty-five"* becomes **25**, *"one hundred"* becomes **100**, *"five thousand"* becomes **5000**. So *"buy two eggs and twelve apples"* becomes *"Buy 2 eggs and 12 apples"* automatically.

## Sharing

Tap **Share with Someone** at the bottom. You'll see:

- **Phone's Share Menu** — opens your native OS share sheet (best for WhatsApp/Telegram/Mail/anything you have installed). Available on most mobile browsers and modern Chrome/Edge.
- **Send by Email** — opens your default email app pre-filled with the title and notes (`mailto:`)
- **WhatsApp** — opens WhatsApp pre-filled with formatted text (`wa.me`)
- **Text Message** — opens your SMS app pre-filled (`sms:`)
- **Copy to Clipboard** — copies the formatted notes for pasting anywhere

> About email "sign-in": no sign-in is required. PaperPad uses your phone's existing email app (whichever one you're already signed into). Direct in-app Gmail send would need a backend and OAuth setup, which a static PWA can't ship.

## Features

- Voice dictation in 30+ languages (Web Speech API)
- Typed input as a fallback — no microphone required
- Spoken **next point** to split into bullets
- Spoken **undo** with many natural phrasings ("erase the last bullet," "delete the last note," etc.)
- Voice + manual table builder with active-cell tracking
- Spoken **numbers → digits** in English
- One-tap export to **PDF**, **.doc** (Word), or **.txt** — tables included
- One-tap **share** to WhatsApp, Email, SMS, or any app via the system share sheet
- Big buttons, large fonts, sky-blue palette designed for older eyes
- Installable as a Progressive Web App on Android and iPhone
- Works offline once installed
- No account, no tracking, no servers — your notes stay on your device

## How to run it locally

Browsers block microphone access on raw `file://` URLs, so serve it locally:

```bash
git clone https://github.com/<your-username>/SCAMslayer.git
cd SCAMslayer
python3 -m http.server 8000
# then open http://localhost:8000
```

## How to ship it to someone's phone

1. Drag the project folder onto **[app.netlify.com/drop](https://app.netlify.com/drop)** — free, no signup, gives you an `https://` URL in seconds.
2. Send the URL on WhatsApp.
3. The recipient taps the link, then chooses **"Add to Home Screen"** (Safari Share menu on iPhone, three-dot menu on Android Chrome). The app installs like a native app.

For an actual `.apk` to attach in WhatsApp: paste the Netlify URL into **[pwabuilder.com](https://www.pwabuilder.com)**, click *Package For Stores → Android*, and download the signed APK. (APKs are Android-only.)

## Tech stack

- **React 18** (loaded from CDN, no build step)
- **Babel Standalone** for in-browser JSX
- **Web Speech API** (`SpeechRecognition`) for voice-to-text in 30+ languages
- **jsPDF** + **jspdf-autotable** for PDF generation
- **Web Share API** + `mailto:` / `wa.me` / `sms:` URI schemes for sharing
- HTML/Word XML for `.doc` export, plain-text Blob with ASCII tables for `.txt`
- Service worker + Web App Manifest for PWA installability and offline use

Everything is a single static folder — no Node, no bundler, no backend.

## Project structure

```
PaperPad/
├── index.html             # the whole app (UI + logic in one file)
├── manifest.webmanifest   # PWA metadata
├── sw.js                  # service worker for offline caching
├── icon-192.png           # home-screen icon (small)
├── icon-512.png           # home-screen icon (large)
├── icon-maskable-512.png  # adaptive icon for Android
└── README.md              # you are here
```

## License

MIT — do whatever you want with it.
